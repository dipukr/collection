package com.batch;

import java.util.List;

import org.springframework.batch.core.Step;
import org.springframework.batch.core.configuration.annotation.EnableBatchProcessing;
import org.springframework.batch.core.job.builder.JobBuilder;
import org.springframework.batch.core.step.builder.StepBuilder;
import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.ItemWriter;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.transaction.PlatformTransactionManager;

@Configuration
@EnableBatchProcessing
public class BatchConfig {

	private JobBuilder jobBuilder;
	private StepBuilder stepBuilder;
	private PersonDAO personDAO;
	private PlatformTransactionManager transactionManager;
	
	@Bean
	public ItemReader<List<Person>> reader() {
		return new PersonReader();
	}
	
	@Bean
	public ItemWriter<List<Person>> writer() {
		return new PersonWriter();
	}
	
	@Bean
	public Step step() {
		return stepBuilder
			.<List<Person>, List<Person>>chunk(1, transactionManager)
			.reader(reader())
			.writer(writer()).build();
	}
}
