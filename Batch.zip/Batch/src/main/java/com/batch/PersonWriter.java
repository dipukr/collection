package com.batch;

import java.util.List;

import org.springframework.batch.item.Chunk;
import org.springframework.batch.item.ItemWriter;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Scope;

@Scope("step")
public class PersonWriter implements ItemWriter<List<Person>> {

	@Autowired
	private PersonDAO personDAO;

	@Override
	public void write(Chunk<? extends List<Person>> chunk) throws Exception {
		List<? extends List<Person>> items = chunk.getItems();
		List<Person> persons = items.stream()
				.flatMap(list -> list.stream())
				.toList();
		personDAO.saveAll(persons);
	}
}
