package com.batch;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;

import org.springframework.batch.item.ItemReader;
import org.springframework.batch.item.NonTransientResourceException;
import org.springframework.batch.item.ParseException;
import org.springframework.batch.item.UnexpectedInputException;
import org.springframework.context.annotation.Scope;

@Scope("step")
public class PersonReader implements ItemReader<List<Person>> {

	@Override
	public List<Person> read() throws Exception, UnexpectedInputException, ParseException, NonTransientResourceException {
		List<Person> persons = new ArrayList<>();
		List<String> lines = Files.lines(Path.of("person.csv")).skip(1).toList();
		for (String line: lines) {
			String[] data = line.split(",");
			Person person = new Person();
			person.setFirstName(data[1]);
			person.setLastName(data[2]);
			person.setEmail(data[3]);
			persons.add(person);
		}
		return persons;
	}
}
